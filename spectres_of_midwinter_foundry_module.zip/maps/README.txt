Place your map images here at these filenames to have scenes reference them:
maps/manor_entrance.png
maps/drawing_room.png
maps/chapel.png
maps/courtyard.png